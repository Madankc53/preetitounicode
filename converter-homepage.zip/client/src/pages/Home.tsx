import { useState, useMemo, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { searchTools, getCategories, TOOLS } from "@/lib/toolsData";
import { Search, ExternalLink, Zap } from "lucide-react";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  
  const results = useMemo(() => {
    return searchTools(searchQuery);
  }, [searchQuery]);

  const categories = getCategories();
  const popularTools = TOOLS.filter(t => t.popular);

  useEffect(() => {
    // Simulate search delay for visual feedback
    setIsSearching(true);
    const timer = setTimeout(() => setIsSearching(false), 100);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const showResults = searchQuery.trim().length > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/50">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center">
              <span className="text-white font-bold text-lg">⚡</span>
            </div>
            <h1 className="text-xl font-bold text-slate-900">thenepal.io</h1>
          </div>
          <div className="text-sm text-slate-600">
            <span className="font-semibold">{TOOLS.length}</span> Tools
          </div>
        </div>
      </header>

      {/* Hero Search Section */}
      <section className="relative pt-16 pb-12 px-4">
        <div className="container max-w-3xl mx-auto">
          {/* Title */}
          <div className="mb-12 text-center">
            <h2 className="text-5xl md:text-6xl font-bold text-slate-900 mb-4 leading-tight">
              Find Your <span className="bg-gradient-to-r from-blue-600 to-blue-700 bg-clip-text text-transparent">Perfect Tool</span>
            </h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Instant access to Nepal's most accurate converters, calculators, and utilities. All free, all private.
            </p>
          </div>

          {/* Search Bar */}
          <div className="relative mb-8">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-blue-600/20 rounded-2xl blur-xl" />
            <div className="relative bg-white rounded-2xl shadow-xl border border-slate-200/50 p-1 flex items-center gap-3">
              <Search className="w-6 h-6 text-slate-400 ml-4" />
              <Input
                type="text"
                placeholder="Search tools... (e.g., 'date', 'currency', 'land')"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 border-0 bg-transparent text-lg placeholder:text-slate-400 focus:outline-none focus-visible:ring-0"
              />
            </div>
            {searchQuery && (
              <div className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-slate-500">
                {results.length} result{results.length !== 1 ? 's' : ''}
              </div>
            )}
          </div>

          {/* Quick Stats */}
          {!showResults && (
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-4 rounded-lg bg-blue-50 border border-blue-100">
                <div className="text-2xl font-bold text-blue-600">{TOOLS.length}</div>
                <div className="text-sm text-blue-600/70">Tools</div>
              </div>
              <div className="p-4 rounded-lg bg-green-50 border border-green-100">
                <div className="text-2xl font-bold text-green-600">100%</div>
                <div className="text-sm text-green-600/70">Private</div>
              </div>
              <div className="p-4 rounded-lg bg-purple-50 border border-purple-100">
                <div className="text-2xl font-bold text-purple-600">Free</div>
                <div className="text-sm text-purple-600/70">Forever</div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Results Section */}
      <section className="pb-20 px-4">
        <div className="container">
          {showResults ? (
            <>
              {/* Search Results */}
              <div className="mb-8">
                <h3 className="text-2xl font-bold text-slate-900 mb-6">
                  Search Results
                </h3>
                {results.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {results.map((tool) => (
                      <ToolCard key={tool.id} tool={tool} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="text-6xl mb-4">🔍</div>
                    <h4 className="text-xl font-semibold text-slate-900 mb-2">No tools found</h4>
                    <p className="text-slate-600">Try searching for something else or browse popular tools below.</p>
                  </div>
                )}
              </div>
            </>
          ) : (
            <>
              {/* Popular Tools */}
              <div className="mb-16">
                <div className="flex items-center gap-2 mb-6">
                  <Zap className="w-5 h-5 text-blue-600" />
                  <h3 className="text-2xl font-bold text-slate-900">Popular Tools</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {popularTools.map((tool) => (
                    <ToolCard key={tool.id} tool={tool} />
                  ))}
                </div>
              </div>

              {/* Categories */}
              {categories.map((category) => {
                const categoryTools = TOOLS.filter(t => t.category === category && !t.popular);
                if (categoryTools.length === 0) return null;
                
                return (
                  <div key={category} className="mb-16">
                    <h3 className="text-2xl font-bold text-slate-900 mb-6">{category}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {categoryTools.map((tool) => (
                        <ToolCard key={tool.id} tool={tool} />
                      ))}
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200/50 bg-slate-50/50 py-12 px-4">
        <div className="container max-w-4xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold text-slate-900 mb-3">Tools</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-blue-600 transition">Converters</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">Calculators</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">Utilities</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-3">Company</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-blue-600 transition">About</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">Blog</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-3">Legal</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-blue-600 transition">Privacy</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">Terms</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">Sitemap</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-3">Follow</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><a href="#" className="hover:text-blue-600 transition">Twitter</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">GitHub</a></li>
                <li><a href="#" className="hover:text-blue-600 transition">LinkedIn</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-200/50 pt-8 text-center text-sm text-slate-600">
            <p>Built with ❤️ for Nepal • © 2026 thenepal.io • All tools are 100% private and free</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

interface ToolCardProps {
  tool: any;
}

function ToolCard({ tool }: ToolCardProps) {
  return (
    <a href={tool.url} target="_blank" rel="noopener noreferrer">
      <Card className="h-full p-6 hover:shadow-lg hover:border-blue-200 transition-all duration-300 cursor-pointer group bg-white hover:bg-blue-50/30">
        <div className="flex items-start justify-between mb-3">
          <span className="text-4xl">{tool.icon}</span>
          <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition opacity-0 group-hover:opacity-100" />
        </div>
        <h4 className="font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition line-clamp-2">
          {tool.name}
        </h4>
        <p className="text-sm text-slate-600 line-clamp-2 mb-3">
          {tool.description}
        </p>
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-slate-500 bg-slate-100 px-2 py-1 rounded">
            {tool.category}
          </span>
          {tool.popular && (
            <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">
              Popular
            </span>
          )}
        </div>
      </Card>
    </a>
  );
}
