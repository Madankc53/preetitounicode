export interface Tool {
  id: string;
  name: string;
  description: string;
  category: string;
  url: string;
  icon: string;
  keywords: string[];
  popular: boolean;
}

export const TOOLS: Tool[] = [
  // Document Tools
  {
    id: "preeti-converter",
    name: "Preeti ↔ Unicode",
    description: "Convert legacy Nepali fonts (Preeti, Kantipur, PCS) to modern Unicode. 100% private, batch upload supported.",
    category: "Document",
    url: "https://converter.thenepal.io/",
    icon: "📄",
    keywords: ["preeti", "unicode", "font", "nepali", "converter", "document", "kantipur", "pcs"],
    popular: true,
  },
  
  // Calendar Tools
  {
    id: "date-converter",
    name: "BS ↔ AD Date Converter",
    description: "Convert between Bikram Sambat (BS) and Gregorian (AD) calendars. Table-driven accuracy for 2000-2100 BS.",
    category: "Calendar",
    url: "https://converter.thenepal.io/date-converter/",
    icon: "📅",
    keywords: ["date", "bs", "ad", "bikram", "sambat", "gregorian", "calendar", "nepali", "converter"],
    popular: true,
  },

  // Real Estate Tools
  {
    id: "land-converter",
    name: "जग्गा कन्वर्टर (Land Converter)",
    description: "Convert Nepali land units: Ropani, Aana, Bigha, Kattha, Daam, and more. Supports both Hill and Terai systems.",
    category: "Real Estate",
    url: "https://converter.thenepal.io/land-converter/",
    icon: "⛰️",
    keywords: ["land", "ropani", "aana", "bigha", "kattha", "daam", "converter", "nepal", "area"],
    popular: true,
  },

  {
    id: "ropani-aana",
    name: "रोपनी आना कन्वर्टर",
    description: "Specialized converter for Hill system land measurements: Ropani, Aana, Paisa, Daam.",
    category: "Real Estate",
    url: "https://converter.thenepal.io/land-converter/",
    icon: "🏔️",
    keywords: ["ropani", "aana", "paisa", "daam", "hill", "land", "converter"],
    popular: false,
  },

  {
    id: "bigha-kattha",
    name: "बिघा कठ्ठा कन्वर्टर",
    description: "Specialized converter for Terai system land measurements: Bigha, Kattha, Dhur.",
    category: "Real Estate",
    url: "https://converter.thenepal.io/bigha-kattha-converter/",
    icon: "🌾",
    keywords: ["bigha", "kattha", "dhur", "terai", "land", "converter"],
    popular: false,
  },

  // Finance Tools
  {
    id: "currency-converter",
    name: "Currency Converter",
    description: "Convert INR to NPR with official peg verification (1 INR = 1.60 NPR). Real-time rates and historical data.",
    category: "Finance",
    url: "https://converter.thenepal.io/currency/inr-to-npr",
    icon: "💱",
    keywords: ["currency", "inr", "npr", "exchange", "rate", "rupee", "converter", "nepal"],
    popular: true,
  },

  // Education Tools
  {
    id: "gpa-calculator",
    name: "GPA to Percentage",
    description: "Convert GPA (Grade Point Average) to percentage. Simplified for Nepali students and educational institutions.",
    category: "Education",
    url: "https://gpatopercentage.thenepal.io",
    icon: "🎓",
    keywords: ["gpa", "percentage", "grade", "calculator", "student", "education"],
    popular: true,
  },

  {
    id: "cgpa-calculator",
    name: "CGPA Calculator",
    description: "Calculate Cumulative GPA (CGPA) from semester grades. Essential for academic planning.",
    category: "Education",
    url: "https://converter.thenepal.io/",
    icon: "📊",
    keywords: ["cgpa", "cumulative", "gpa", "grade", "calculator", "semester"],
    popular: false,
  },

  {
    id: "percentage-calculator",
    name: "Percentage Calculator",
    description: "Calculate percentages, marks, and grades. Useful for students and educators.",
    category: "Education",
    url: "https://converter.thenepal.io/",
    icon: "📈",
    keywords: ["percentage", "calculator", "marks", "grade", "score"],
    popular: false,
  },

  // Utility Tools
  {
    id: "unit-converter",
    name: "Unit Converter",
    description: "Convert between various measurement units: length, weight, temperature, volume, and more.",
    category: "Utility",
    url: "https://converter.thenepal.io/unit-converter/",
    icon: "📏",
    keywords: ["unit", "converter", "length", "weight", "temperature", "volume", "measurement"],
    popular: false,
  },

  {
    id: "age-calculator",
    name: "Age Calculator",
    description: "Calculate age from date of birth. Supports both BS (Bikram Sambat) and AD (Gregorian) calendars.",
    category: "Utility",
    url: "https://converter.thenepal.io/",
    icon: "🎂",
    keywords: ["age", "calculator", "birthday", "date", "birth"],
    popular: false,
  },
];

export function searchTools(query: string): Tool[] {
  if (!query.trim()) return TOOLS.filter(t => t.popular);
  
  const lowerQuery = query.toLowerCase();
  
  return TOOLS.filter(tool => {
    // Check name
    if (tool.name.toLowerCase().includes(lowerQuery)) return true;
    
    // Check description
    if (tool.description.toLowerCase().includes(lowerQuery)) return true;
    
    // Check keywords
    if (tool.keywords.some(k => k.includes(lowerQuery))) return true;
    
    // Check category
    if (tool.category.toLowerCase().includes(lowerQuery)) return true;
    
    return false;
  }).sort((a, b) => {
    // Prioritize exact name matches
    const aNameMatch = a.name.toLowerCase().startsWith(lowerQuery);
    const bNameMatch = b.name.toLowerCase().startsWith(lowerQuery);
    if (aNameMatch && !bNameMatch) return -1;
    if (!aNameMatch && bNameMatch) return 1;
    
    // Then prioritize popular tools
    if (a.popular && !b.popular) return -1;
    if (!a.popular && b.popular) return 1;
    
    return 0;
  });
}

export function getToolsByCategory(category: string): Tool[] {
  return TOOLS.filter(t => t.category === category);
}

export function getCategories(): string[] {
  return Array.from(new Set(TOOLS.map(t => t.category)));
}
